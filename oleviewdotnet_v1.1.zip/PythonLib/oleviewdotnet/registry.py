﻿def get():
	import OleViewDotNet

	return OleViewDotNet.COMRegistry.Instance
	